function SdB=fnMocVDb(A)

SdB=10*log10(A.*A);
