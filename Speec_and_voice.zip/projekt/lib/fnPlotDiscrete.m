function fnPlotDiscrete(n,x,color)

plot(n,x,'o','Color',color)
hold on
line([n; n], [zeros(size(x)); x],'Color',color)

end