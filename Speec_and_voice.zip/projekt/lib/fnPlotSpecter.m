function fnPlotSpecter(x,A,phi)

n=[0:length(x)-1]';k=n;

fig=figure; 

subplot(3,1,1)
fnPlotDiscrete(n,x,'b')
xlabel('n'),ylabel('x')

subplot(3,1,2)
fnPlotDiscrete(k,A,'g')
xlabel('k'),ylabel('A')

subplot(3,1,3)
fnPlotDiscrete(k,phi,'r')
xlabel('k'),ylabel('phi')
