function dataAv=fnMovingAverage(data,n)

sD=size(data);
dataAv=zeros(size(data));

dataAv(1:n)=data(1:n);
for i=1:n
    dataAv(i)=sum(data(1:i))/i;
end

for i=n+1:sD(1)
    dataAv(i,:)=dataAv(i-1,:)+data(i,:)/n-data(i-n,:)/n;
end

% for i=n:sD(1)
%     dataAv(i)=sum(data(i-n+1:i))/n;
% end
