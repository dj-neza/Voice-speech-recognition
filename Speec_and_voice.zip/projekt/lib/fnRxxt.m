function Rxxt=fnRxxt(x)

    Rxxt=fnRxyt(x,x);

end