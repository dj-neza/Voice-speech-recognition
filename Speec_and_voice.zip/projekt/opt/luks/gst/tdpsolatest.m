function y=test(playwav)

[s,fs] =readwav(playwav);

pscale=0.7; %pitch scale ratio
tscale=1.5; %time scale ratio

pm = find_pmarks(s,fs); %determine pitch marks
[vuv]=detect_vuv(s,fs,pm); %voiced/unvoiced decision
plot_pmarks(s,fs,pm,vuv); %plot pitch marks
%soundsc(s,fs);

y = tdpsola(s,fs,pscale,tscale,pm,vuv); %TD-PSOLA
soundsc(y,fs)
%soundsc([s; zeros(fs,1); y],fs);

