function y = fdpsola(s,fs,pscale,tscale,pm,vuv);
% vuv: her pitch mark aras�ndaki k�sm�n v/uv decision'�
%      (length(vuv)=length(pm)-1)
%      unvoiced ise pitch scaling yap�lm�yor

if (pscale ==1 & tscale==1)
   y=s;
else
   %Find pitch marks if necessary
   if (nargin==4)
      pm = find_pmarks(s,fs);
   end
   %Do v/uv detection if necessary here
   if (nargin<6)
      %vuv=ones(length(pm)-1,1);%detect v/uv here!!!
      vuv=detect_vuv(s,fs,pm);
   end
   
   
end
