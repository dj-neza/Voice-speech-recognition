function msaudio(fs,nbits)
% Pridobivanje informacije o audio napravah v Microsoft Windows okolju. 
%
% Vhod: 
%      fs    �elena frekvenca vzor�enja
%      nbits �eleno �tevilo bitov kvantizacije amplitude 
%

% Preverimo, �e smo v Microsofr Windows okolju
if ~ispc
    fprintf(1,'Ta funkcija je podprta le v Microsoft Windows okolju');
    return;
end

if nargin < 2
    nbits = 16;
end
if nargin < 1
    fs = 16000;
end

% Vrednost 0 ozna�uje avdio vhodne naprave in vrednost '1' izhodne naprave
noutputs=audiodevinfo(0);
ninputs=audiodevinfo(1);

% Pridobivanje imena naprav v Windows okolju. 
fprintf(1,'Vhodne avdio naprave:\n');
for i=0:ninputs-1
    fprintf(1,'%d: %s\n',i,audiodevinfo(1, i));
end

fprintf(1,'Izhodne avdio naprave:\n');
for i=0:noutputs-1
    fprintf(1,'%d: %s\n',i,audiodevinfo(0, i));
end

% Preverimo, �e prvi vhod podpira izbrano vzor�enje signala
if ~audiodevinfo(1,0,fs,nbits,1)
    fprintf(1,'Izbrana naprava ne podpira izbranega vzor�enja');
end  

fprintf(1,'Vhodna naprava "%s" podpira  vzor�enje %d Hz in %d bitov\n',... 
    audiodevinfo(1, 0),fs,nbits);


end

