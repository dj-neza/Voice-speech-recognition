function plot_pmarks(s,fs,pm,vuv)

smax = max(abs(s));
mark = zeros(size(s));

for i=1:length(pm)-1
    mark(pm(i))=(2*vuv(i)-1)*smax;
end

t=0:1/fs:(length(s)-1)/fs;
plot(t,s,'k');
xlabel('t (sek)');ylabel('x(t)');
title('Analiziran signal');
hold on; 
plot(t,mark,'r');
axis tight;