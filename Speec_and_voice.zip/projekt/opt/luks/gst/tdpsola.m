function y = tdpsola(s,fs,pscale,tscale,pm,vuv);
%
% Time-Domain Pitch Synchronous Overlap Add Method 
%
% Usage: y = tdpsola(s,fs,pscale,tscale,pm,vuv)
%
% Simple usage: y = tdpsola(s,fs,pscale,tscale) 	
%
% Inputs:
%     s	     input speech signal
%     fs     sample rate in Hz 
%     pscale pitch scale (eg. 0.7)
%     tscale time scale (eg. 1.5)
%     pm     an array of pitch marking sample indexes
%     vuv    an array of voice-unvoiced binary flags for each pitch period
%
% Output:	y     modified speech signal.
%
if (pscale ==1 & tscale==1)
   y=s;
else
   %Find pitch marks if necessary
   if (nargin==4)
      pm = find_pmarks(s,fs);
   end
   %Do v/uv detection if necessary here
   if (nargin<6)
      %vuv=ones(length(pm)-1,1);%detect v/uv here!!!
      vuv=detect_vuv(s,fs,pm);
   end
   
   %Apply pitch scaling on the pitch marks
   % and find new pitch marks (pm_ps)
   pm_ps=pm;
   if (pscale~=1)
      pshift=0;
      for i = 2:length(pm)
         T0=pm(i)-pm(i-1);
         if (vuv(i-1)>0)
            if (pscale>1)
               pshift=pshift-round(T0*(pscale-1)/pscale);
            else
               pshift=pshift+round(T0*(1/pscale-1));
            end
         end
         pm_ps(i)=pm(i)+pshift;
      end
   end
   
   %Find frames to be repeated/deleted for time scaling
   % and store this information in useds
   new_tscale=tscale*pm(length(pm))/pm_ps(length(pm_ps));
   avg=sum(diff(pm_ps))/(length(pm_ps)-1);
   if (new_tscale>1)
      useds=zeros(1,length(pm_ps)-2);
      tot=new_tscale;
      for i = 1 : length(useds)
         while(tot>1)
            useds(i)=useds(i)+1;
            %tot=tot-1;
            tot=tot-(pm_ps(i+1)-pm_ps(i))/avg;
          end
         tot=tot+new_tscale;
      end
   elseif (new_tscale<1)
      useds=ones(1,length(pm_ps)-2);
      tot=new_tscale;
      for i = 1 : length(useds)
         while(tot<1)
            useds(i)=useds(i)-1;
            %tot=tot+1;
            tot=tot+(pm_ps(i+1)-pm_ps(i))/avg;
         end
         tot=tot-(1-new_tscale);
      end
   end

   %Synthesize the signal with overlap-add using pm_ps and useds
   start=1;
   count=1;
   for i=1:length(useds)
      if (useds(i)>0)
         final(count,:)=[start pm(i) pm(i+2) 0];
         count=count+1;
         start=start+pm_ps(i+1)-pm_ps(i)+1;   
      end
      for j=2:useds(i)
         final(count,:)=[start pm(i) pm(i+2) mod(j,2)];
         count=count+1;
         start=start+pm_ps(i+1)-pm_ps(i)+1;
      end
   end
   numfrm=size(final,1);
   ylen=max(final(:,1)+(final(:,3)-final(:,2)+1));
   y=zeros(ylen,1);
   if (pscale>1)
      w=zeros(size(y));
   end
   for i = 1 : numfrm
      start=final(i,1);
      len=final(i,3)-final(i,2)+1;
      wgt=window(len,'han');
      frm=s(final(i,2):final(i,3));
      if (final(i,4))
         frm=wrev(frm);
      end
      y(start:start+len-1)=y(start:start+len-1)+frm.*wgt;
      if (pscale>1)
         w(start:start+len-1)=w(start:start+len-1)+wgt;
      end
   end  
   
   if (pscale>1)
      for i=1:ylen
         if w(i)==0
            w(i)=1;
         end
         y(i)=y(i)/w(i);
      end
   end
end