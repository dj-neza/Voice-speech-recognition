function [ ] = usound(s, fs)
%USOUND Plays sound on ALSA-based linux machines or macs

if nargin < 2
    fs = 16000;
end

filename = ['/tmp/' getenv('USER') '_matplay.wav'];
wavwrite(s,fs,filename);

if isunix
    eval(['!aplay ' filename ' &']);
end
