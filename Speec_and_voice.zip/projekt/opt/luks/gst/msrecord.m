function s=msrecord(fs,nbits)

% Snemanje audio signala v Microsoft Windows okolju. 
% Vhod: 
%      fs    �elena frekvenca vzor�enja
%      nbits �eleno �tevilo bitov kvantizacije amplitude 
%
% Izhod: 
%      s     Vektor odtipkov zvo�nega signala
%

% Preverimo, �e smo v Microsofr Windows okolju
if ~ispc
    fprintf(1,'Ta funkcija je podprta le v Microsoft Windows okolju');
    return;
end

if nargin < 2
    nbits = 16;
end
if nargin < 1
    fs = 16000;
end

%Odpremo snemalnik z izbranim vzor�enjem in privzetim avdio vhodom
r=audiorecorder(fs,nbits,1);
fprintf(1,'Pritisnite tipko za pri�etek snemanja ...\n');
pause;
record(r);
fprintf(1,'Audio se snema, pritisni tipko za prekinitev ...\n');
pause;
stop(r);

fprintf(1,'Predvajam posneto ...\n');
p=play(r);

while isplaying(p)
    pause(0.1);
end

s=getaudiodata(r, 'double');

end

