function [dtwd,dm]=dtwplot(s1,fs1,s2,fs2,c1,c2)

n1 = size(c1,1);
n2 = size(c2,1);

[dtwd,dm,d,pp]=dtwarp(c1,c2);

set(0,'Units','pixels');
ssize = get(0,'ScreenSize');
swidth=ssize(3);sheight=ssize(4);

fheight=0.45*sheight;
fwidth=fheight*n2/n1;

figure;
set(gcf,'Units','pixels', 'Position', [0.05*swidth,0.90*sheight-fheight,fwidth,fheight]);

t1=0:1/fs1:(length(s1)-1)/fs1;
subplot('Position',[0.05 0.2 0.14 0.782]);
plot(s1,t1);axis tight;
set(gca,'xtick',[]);set(gca,'xticklabel',[]);

subplot('Position',[0.2 0.2 0.78 0.78]);
imagesc(d); axis tight; 
hold on; plot(pp(:,2),pp(:,1),'r');hold off;
colormap(gray);
set(gca,'YDir','normal');
set(gca,'xtick',[]);set(gca,'xticklabel',[]);
set(gca,'ytick',[]);set(gca,'yticklabel',[]);

t2=0:1/fs2:(length(s2)-1)/fs2;
subplot('Position',[0.2 0.05 0.782 0.14]);
plot(t2,s2);axis tight;
set(gca,'ytick',[]);set(gca,'yticklabel',[]);

end

