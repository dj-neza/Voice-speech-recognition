function [vuv]=detect_vuv(s,fs,pm);
% Return V/UV decisions considering pitch marks
% Two pitch periods=1 frame, so length of vuv=length of pm-1

EN_TH = 0.25; %Energy threshold
ZCR_TH = 0.75; %Zero-crossing rate threshold

s=s-mean(s);%mean is Average or mean value of arrays
for i = 1:length(pm)-1
   frm=s(pm(i):pm(i+1));
   frmlen=pm(i+1)-pm(i+1)+1;
   en(i,1)=log(energy(frm,frmlen));
   zcr(i,1)=zerocr_frm(frm);
end

%All voiced
vuv=ones(length(en),1);

% Energy based detection
[new_en] = sort(en);
enInd=round(EN_TH*length(en));
if (enInd<1)
   enInd=1;
end
ind=find(en<new_en(enInd));
vuv(ind)=0;

% Zero-crossing rate based detection
[new_zcr] = sort(zcr);
zcrInd=round(ZCR_TH*length(zcr));
if (zcrInd<1)
   zcrInd=1;
end
ind=find(zcr>new_zcr(zcrInd));
vuv(ind)=0;