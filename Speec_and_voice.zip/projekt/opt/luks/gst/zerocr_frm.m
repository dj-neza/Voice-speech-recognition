function Z = zerocr(frm);
% ZEROCR - Calculates the average zero-crossing rate of the input frame
%��ʱ�������
Z = 0;
lenFrm = length(frm);
for k = 2 : lenFrm
   Z = Z + abs(sign(frm(k)) - sign(frm(k - 1)));
end

Z = Z / (2 * lenFrm);
