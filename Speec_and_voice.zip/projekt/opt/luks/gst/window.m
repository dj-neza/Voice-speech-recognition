% [out]=window(wsize,name)
%
% Function to calculate the pitch adaptive Hamming window
%
%  wsize : size of the window in terms of samples
%                    (must be greater than zero)
%  name : type of the window
%           'ham' for Hamming   (DEFAULT)
%           'han' for Hanning
%           'bar' for Bartlett
%           'bla' for Blackman
%           'rec' for rectangular
%           'tri' for triangular
%         
%  out  : output window coefficients

function [out]=window(wsize,name)

% Check input
if wsize<1 display('Error: in window size...It will be taken 20');
   wsize=20;   
end

% The type of the window will be Hamming if 'type' is not specified 
% or if it is specified wrong
if nargin<2 
   display(' Warning: window name not specified...It will be taken as Hamming');
   name='ham';
end
if not(size(name,2)==3)
   display('Error: in window name...It will be taken as Hamming');
   name='ham';   
end


% 'name' will be automatically converted to lowercase
name=lower(name);

% Calculate the window coefficients
if name=='ham' out=hamming(wsize);   
elseif name=='han' out=hamming(wsize);
elseif name=='bar' out=bartlett(wsize);
elseif name=='bla' out=blackman(wsize);
elseif name=='rec' out=boxcar(wsize);
elseif name=='tri' out=triang(wsize);
else
   display('Error: in window name...It will be taken as Hamming');
   out=hamming(wsize);   
end   