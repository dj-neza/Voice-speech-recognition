function lpcformanti(s,fs,wsize,nfft,p,ti)

t=0:1/fs:(length(s)-1)/fs;

sw=s.*hamming(wsize);

[ar,xi,kappa,ehat]=lpcana(sw,p);
[theta,f] = freqz(sqrt(ehat'*ehat),ar,nfft,fs);

so=fft(sw,2*nfft);

figure;
subplot(211);
plot(t,s);axis tight;
xlabel('t (sekunde)');
ylabel('x(t)');
title('Govorni signal');

subplot(212);
plot(f,20*log10(abs(theta)));
hold on;
plot(f,20*log10(abs(so(1:nfft))),'Color','green');
axis tight;
xlabel('{\it F}  [Hz]');
ylabel('|\theta(\omega)|  [dB]');
title('Spekter');

end
