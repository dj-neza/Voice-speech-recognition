%en=energy(frm,frm_size)
%
% Calculates the energy of input frame

function en=energy(frm,frm_size)

en=sum((frm(1:frm_size)).^2);
