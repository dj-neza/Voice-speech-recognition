function varargout = GUI(varargin)
% GUI MATLAB code for GUI.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI

% Last Modified by GUIDE v2.5 01-Jun-2016 23:48:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI is made visible.
function GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI (see VARARGIN)
if exist('lock_sample_1.wav', 'file')
  set(handles.unlock,'Enable','on');
end
% Choose default command line output for GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in lock.
function lock_Callback(hObject, eventdata, handles)
    set(handles.lock1, 'String', ' ');
    set(handles.unlock1, 'String', ' ');
    set(handles.lock2, 'String', ' ');
    set(handles.unlock2, 'String', ' ');
    recObj = audiorecorder(16000, 24, 2);
    for i = 1:3
        set(handles.lock1, 'String', strcat(num2str(i),'/3'));
        recordblocking(recObj, 3);
        y = getaudiodata(recObj);
        filename = strcat('C:\Users\FireFairy\Documents\Faks\DOS\projekt\lock_database\lock_sample_', num2str(i), '.wav');
        audiowrite(filename, y, 16000);
        if i == 3
            set(handles.lock1, 'String', 'Over');
        end
    end
    
    set(handles.unlock,'Enable','on');
% hObject    handle to lock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in unlock.
function unlock_Callback(hObject, eventdata, handles)
    set(handles.lock1, 'String', ' ');
    set(handles.unlock1, 'String', ' ');
    set(handles.lock2, 'String', ' ');
    set(handles.unlock2, 'String', ' ');
    recObj = audiorecorder(16000, 24, 2);
    set(handles.unlock1, 'String', 'Speak');
    recordblocking(recObj, 3);
    set(handles.unlock1, 'String', 'Over');
    y = getaudiodata(recObj);
    filename2 = strcat('C:\Users\FireFairy\Documents\Faks\DOS\projekt\comparison_database\unlock_sample.wav');
    audiowrite(filename2, y, 16000);
    
    min = 5000;
    index = 0;
    for i = 1:12
        filename = strcat('C:\Users\FireFairy\Documents\Faks\DOS\projekt\lock_database\lock_sample_', num2str(i), '.wav');
        filename2 = strcat('C:\Users\FireFairy\Documents\Faks\DOS\projekt\comparison_database\unlock_sample.wav');
        [n,n1] = audioread(filename);
        lock_vec = melcepst(n, n1, 'M');
        [nn,nn1] = audioread(filename2);
        unlock_vec = melcepst(nn, nn1, 'M');
        minni = dtwarp(lock_vec,unlock_vec);
        disp(minni);
        if minni < min
            min = minni;
            index = i;
        end
    end
    
    if index == 1 || index == 2 || index == 3 
        if min <= 2.1
           result = sprintf('Unlock with database: success!\nUnlock with threshold: success!');
           uiwait(msgbox(result));
        else 
           result = sprintf('Unlock with database: success!\nUnlock with threshold: failure!');
           uiwait(msgbox(result)); 
        end
    else
        if min <= 2.1
           result = sprintf('Unlock with database: failure!\nUnlock with threshold: success!');
           uiwait(msgbox(result));
        else 
           result = sprintf('Unlock with database: failure!\nUnlock with threshold: failure!');
           uiwait(msgbox(result)); 
        end
    end
    
% hObject    handle to unlock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in add.
function add_Callback(hObject, eventdata, handles)
    set(handles.lock1, 'String', ' ');
    set(handles.unlock1, 'String', ' ');
    set(handles.lock2, 'String', ' ');
    set(handles.unlock2, 'String', ' ');
    recObj = audiorecorder(16000, 24, 2);
    ime=get(handles.name, 'string');
    prazno = 'Insert name here';
    izpolnjeno = strcmp(ime, prazno);
    if izpolnjeno == 0
        set(handles.lock2, 'String', 'Speak');
        recordblocking(recObj, 5);
        set(handles.lock2, 'String', 'Over');
        y = getaudiodata(recObj);
        filename = strcat('C:\Users\FireFairy\Documents\Faks\DOS\projekt\voice_database\', ime, '.wav');
        audiowrite(filename, y, 16000);
    else 
        set(handles.lock2, 'String', 'Enter name');
    end
    
    set(handles.unlock,'Enable','on');
% hObject    handle to add (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in run.
function run_Callback(hObject, eventdata, handles)
    set(handles.lock1, 'String', ' ');
    set(handles.unlock1, 'String', ' ');
    set(handles.lock2, 'String', ' ');
    set(handles.unlock2, 'String', ' ');
    recObj = audiorecorder(16000, 24, 2);
    set(handles.unlock2, 'String', 'Speak');
    recordblocking(recObj, 5);
    set(handles.unlock2, 'String', 'Over');
    y = getaudiodata(recObj);
    filename = 'C:\Users\FireFairy\Documents\Faks\DOS\projekt\comparison_database\recognition_sample.wav';
    audiowrite(filename, y, 16000);
    
    database = dir('C:\Users\FireFairy\Documents\Faks\DOS\projekt\voice_database');
    velikost = length(database(not([database.isdir])));

    match = 0;
    index = 0;
        for i = 1:velikost
            disp(database(i+2).name);
            filename = strcat('C:\Users\FireFairy\Documents\Faks\DOS\projekt\voice_database\', database(i+2).name);
            filename2 = strcat('C:\Users\FireFairy\Documents\Faks\DOS\projekt\comparison_database\recognition_sample.wav');
            [n,n1] = audioread(filename);
            [nn,nn1] = audioread(filename2);

           N = abs(fft(n)); %posnetek iz baze
           % N = resize(N, 1, (length(N)-1)/2);
           NN = abs(fft(nn)); %posnetek za referenco
           % NN = resize(NN, 1, (length(NN)-1)/2);
    
           dist = 0;
           for j = 300:3400 %najbolj relevantne frekvence
               F1 = zeros(1, 2);
               F1(1) = N(round(j)-1) + N(round(j)) + N(round(j)+1);
               F1(2) = NN(round(j)-1) + NN(round(j)) + NN(round(j)+1);
               dist = dist + abs(F1(1) - F1(2));
           end
           disp(dist);
           if (dist < match || match == 0) 
              match = dist;
              index = i;
           elseif match == 0
              match = dist;
              index = i;
           end
           dist = 0;
        end
        
        if index > 0
            speaker = database(index+2).name;
            speaker = speaker(1:end-4);
            message = strcat('Speaker recognised: ', speaker);
            result = sprintf(message);
            uiwait(msgbox(result));
        else
            result = sprintf('Speaker not part of the database.');
            uiwait(msgbox(result));
        end
        
    
% hObject    handle to run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function name_Callback(hObject, eventdata, handles)
% hObject    handle to name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of name as text
%        str2double(get(hObject,'String')) returns contents of name as a double


% --- Executes during object creation, after setting all properties.
function name_CreateFcn(hObject, eventdata, handles)
% hObject    handle to name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
