function X=fnFFT(x)

X=fft(x)/length(x);