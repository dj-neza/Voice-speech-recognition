function [dtwd,dm,d,pp]=dtwarp(c1,c2)

n1 = size(c1,1);
n2 = size(c2,1);

d = zeros(n1,n2);
for i = 1:n1
    for j = 1:n2
        d(i,j) = norm(c1(i,:) - c2(j,:));
    end
end


dm = d;
phi = zeros(n1,n2);
for i = 1:n1
    for j = 1:n2
        dmin = 0;
        bp = 0;
        if i > 1 && j > 1
            [dmin, bp] = min([dm(i-1, j-1), dm(i-1, j), dm(i, j-1)]);
        elseif i > 1
            dmin = dm(i-1,j); 
            bp = 2;            
        elseif j > 1
            dmin = dm(i, j-1); 
            bp = 3;            
        end       
        dm(i,j) = dm(i,j)+dmin;
        phi(i,j) = bp;        
    end
end

i = n1; j = n2; k = 1;
pp = zeros(n1+n2,2);
while i > 1 && j > 1
    bp = phi(i,j);
    if (bp == 1)
        i = i-1;
        j = j-1;
    elseif (bp == 2)
        i = i-1;
    elseif (bp == 3)
        j = j-1;
    end
    pp(k,:)=[i j];
    k = k + 1;
end
pp = pp(1:k-1,:);

dtwd = dm(n1,n2)/length(pp);

end

