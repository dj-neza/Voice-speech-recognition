
function w = hamming(n)

if nargin == 0
 help hamming;
 return;
end;

n = n(:); 
[hig, wid] = size(n);

if  wid > 1;  n = wid; end; 

w = (.54 - .46*cos(2*pi*(0:n-1)'/(n-1))).';

if  hig > 1;
ww = w;  
 for jj = 2 : hig;
 w(jj,:) =  ww;
 end; 
end; 